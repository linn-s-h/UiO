
class SortRute extends Rute{

    public SortRute(int rad, int kol, Labyrint labyrint){
        super(rad, kol, labyrint);
    }
    @Override
    public void finn(Rute fra){}

    @Override
    public String toString(){
        return "#";
    }
}